package projectManagementSystem.entity;

public enum Role {
    ADMIN,
    LEADER,
    USER
}
