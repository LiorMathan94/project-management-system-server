package projectManagementSystem.entity;

public enum Importance {
    LEVEL1,
    LEVEL2,
    LEVEL3,
    LEVEL4,
    LEVEL5
}
